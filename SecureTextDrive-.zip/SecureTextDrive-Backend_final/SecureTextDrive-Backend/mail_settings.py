# mail_settings.py

MAIL_SERVER = 'smtp.hostinger.com'
MAIL_PORT = 465
MAIL_USERNAME = 'support@hmmbo.com'
MAIL_PASSWORD = 'R0$hankumar'
MAIL_USE_TLS = False
MAIL_USE_SSL = True
