from flask_mail import Mail

mail = Mail()
print("loaded")